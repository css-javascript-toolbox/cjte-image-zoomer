<script type="text/javascript">
    window.addEventListener('load', function() {
        jQuery("#<?php echo $cb->containerElementId() ;?> img").imagezoomsl(<?php echo $cb->params()->json() ?>);
    });
</script>